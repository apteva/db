package db

import "fmt"

type probeLocation struct {
	page uint32
	slot int
}

// Experimental complete routing map. Caller holds the writer lock.
func (db *DB) buildProbeIndex() error {
	m := make(map[string]probeLocation)
	var walk leafWalk
	v := view{db: db}
	for {
		p, _, err := walk.next(v, nil)
		if err != nil {
			return err
		}
		if p == nil {
			break
		}
		for i := 0; i < p.numCells(); i++ {
			m[string(p.leafKey(i))] = probeLocation{walk.id, i}
		}
	}
	db.probeIndex, db.probeGeneration = m, db.treeGen
	return nil
}

func (db *DB) ProbeStatus() string {
	db.mu.RLock()
	defer db.mu.RUnlock()
	return fmt.Sprintf("keys=%d active=%v generation=%d tree=%d", len(db.probeIndex), db.probeIndex != nil && db.probeGeneration == db.treeGen, db.probeGeneration, db.treeGen)
}
