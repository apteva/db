package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"runtime/pprof"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/sys/unix"
)

var flagResourceCRUD = flag.Bool("resourcecrud", false, "resource runner: consume scan values and include updates, mixed operations and deletes")
var flagResourceReads = flag.Int("resourcereadpasses", 1, "complete hit/miss/parallel passes per measured resource phase")
var flagResourceScans = flag.Int("resourcescanpasses", 1, "complete value scans per measured resource phase")
var flagResources = flag.Bool("resources", false, "JSON CPU/RSS/allocation comparison; exactly one engine and workload per process")

type resourcePhase struct {
	MinorFaults   int64   `json:"minor_page_faults"`
	MajorFaults   int64   `json:"major_page_faults"`
	Phase         string  `json:"phase"`
	Ops           int     `json:"ops"`
	WallSeconds   float64 `json:"wall_seconds"`
	UserSeconds   float64 `json:"user_seconds"`
	SystemSeconds float64 `json:"system_seconds"`
	CPUNsPerOp    float64 `json:"cpu_ns_per_op"`
	WallNsPerOp   float64 `json:"wall_ns_per_op"`
	AverageCores  float64 `json:"average_cores"`
	RSSBytes      int64   `json:"rss_bytes"`
	PeakRSSBytes  int64   `json:"process_peak_rss_bytes_so_far"`
	Footprint     uint64  `json:"memory_footprint_bytes"`
	PeakFootprint uint64  `json:"process_peak_memory_footprint_bytes_so_far"`
	GoHeapBytes   uint64  `json:"go_heap_bytes"`
	GoAllocated   uint64  `json:"go_allocated_bytes"`
	GoAllocs      uint64  `json:"go_allocations"`
	GCCycles      uint32  `json:"gc_cycles"`
}

func resourceUsage() unix.Rusage {
	var r unix.Rusage
	if err := unix.Getrusage(unix.RUSAGE_SELF, &r); err != nil {
		panic(err)
	}
	return r
}

func resourceSeconds(t unix.Timeval) float64 {
	return float64(t.Sec) + float64(t.Usec)/1e6
}

func resourcePeak(r unix.Rusage) int64 {
	// macOS reports bytes; Linux reports KiB. This is a process lifetime
	// high-water mark, never a phase-local peak or Go-only heap size.
	if runtime.GOOS == "darwin" {
		return r.Maxrss
	}
	return r.Maxrss * 1024
}

func resourceRSS() int64 {
	// Run outside measured phases. ps includes Go, native SQLite, and
	// resident file mappings, unlike runtime.MemStats. Child CPU is not
	// included in RUSAGE_SELF.
	b, err := exec.Command("ps", "-o", "rss=", "-p", strconv.Itoa(os.Getpid())).Output()
	if err != nil {
		panic(err)
	}
	n, err := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
	if err != nil {
		panic(err)
	}
	return n * 1024
}

func measureResource(phase string, ops int, fn func() error) resourcePhase {
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	u0 := resourceUsage()
	start := time.Now()
	if err := fn(); err != nil {
		panic(phase + ": " + err.Error())
	}
	d := time.Since(start).Seconds()
	u1 := resourceUsage()
	runtime.ReadMemStats(&after)
	user := resourceSeconds(u1.Utime) - resourceSeconds(u0.Utime)
	system := resourceSeconds(u1.Stime) - resourceSeconds(u0.Stime)
	footprint, peakFootprint := resourceFootprint()
	return resourcePhase{
		Phase: phase, Ops: ops, WallSeconds: d, UserSeconds: user, SystemSeconds: system,
		MinorFaults: u1.Minflt - u0.Minflt, MajorFaults: u1.Majflt - u0.Majflt,
		CPUNsPerOp: (user + system) * 1e9 / float64(ops), WallNsPerOp: d * 1e9 / float64(ops),
		AverageCores: (user + system) / d, RSSBytes: resourceRSS(), PeakRSSBytes: resourcePeak(u1),
		Footprint: footprint, PeakFootprint: peakFootprint,
		GoHeapBytes: after.HeapAlloc, GoAllocated: after.TotalAlloc - before.TotalAlloc,
		GoAllocs: after.Mallocs - before.Mallocs, GCCycles: after.NumGC - before.NumGC,
	}
}

func runResourceBench(dir string, openers map[string]opener) {
	name, workload := *flagEngines, *flagWork
	if strings.Contains(name, ",") || strings.Contains(workload, ",") || *flagReps != 1 || *flagDurable {
		panic("resources requires one engine, one workload, reps=1 and durable=false; repeat in separate processes")
	}
	if (workload != "random" && workload != "seq") || *flagN < 1 || *flagVal < 1 || *flagPar < 1 || *flagResourceReads < 1 || *flagResourceScans < 1 {
		panic("invalid resource workload, count, value size or readers")
	}
	op, ok := openers[name]
	if !ok {
		panic("unknown resource engine " + name)
	}
	baseline := resourceRSS()
	baselineFootprint, _ := resourceFootprint()
	keys, vals, order, misses := genWorkload(workload, *flagN, *flagVal)
	runtime.GC()
	fixtureRSS := resourceRSS()
	fixtureFootprint, _ := resourceFootprint()
	edir, err := os.MkdirTemp(dir, name+"-resources-")
	if err != nil {
		panic(err)
	}
	var db kv
	var phases []resourcePhase
	record := func(phase string, ops int, fn func() error) {
		r := measureResource(phase, ops, fn)
		phases = append(phases, r)
		if os.Getenv("APTEVA_RESOURCE_DIAGNOSTICS") != "" {
			if d, ok := db.(*ours); ok {
				fmt.Fprintf(os.Stderr, "stats %s %+v\n", phase, d.db.Stats())
			}
			if dir := os.Getenv("APTEVA_RESOURCE_HEAP_DIR"); dir != "" {
				if err := os.MkdirAll(dir, 0755); err != nil {
					panic(err)
				}
				f, err := os.Create(filepath.Join(dir, phase+".pprof"))
				if err != nil {
					panic(err)
				}
				runtime.GC() // diagnostic runs only: include allocations since the previous GC
				if err := pprof.WriteHeapProfile(f); err != nil {
					panic(err)
				}
				f.Close()
			}
		}
		fmt.Fprintf(os.Stderr, "%s %s %-18s wall=%.3fs cpu=%.3fs rss=%.1fMiB\n", name, workload, phase,
			r.WallSeconds, r.UserSeconds+r.SystemSeconds, float64(r.RSSBytes)/(1<<20))
	}
	record("open", 1, func() error { db, err = op(edir); return err })
	var scan func(func([]byte, []byte) bool) error
	var remove func([]byte) error
	if *flagResourceCRUD {
		scan, remove, err = resourceCRUD(db)
		if err != nil {
			panic(err)
		}
	}
	n, vs := *flagN, *flagVal
	record("insert", n, func() error {
		for i := 0; i < n; i++ {
			if err := db.Upsert(keys[i*16:(i+1)*16], vals[i*vs:(i+1)*vs]); err != nil {
				return err
			}
		}
		return nil
	})
	record("settle", n, db.Settle)
	var buf []byte
	check := func(rd reader, i int, dst []byte) ([]byte, error) {
		v, found, err := rd.Find(keys[i*16:(i+1)*16], dst)
		if err != nil {
			return nil, err
		}
		if !found || len(v) != vs || v[0] != vals[i*vs] || v[vs-1] != vals[(i+1)*vs-1] {
			return nil, fmt.Errorf("bad value at %d, found=%v len=%d", i, found, len(v))
		}
		return v, nil
	}
	record("find-hit", n*(*flagResourceReads), func() error {
		for pass := 0; pass < *flagResourceReads; pass++ {
			for _, i := range order {
				buf, err = check(db, i, buf)
				if err != nil {
					return err
				}
			}
		}
		return nil
	})
	record("find-miss", n*(*flagResourceReads), func() error {
		for pass := 0; pass < *flagResourceReads; pass++ {
			for i := 0; i < n; i++ {
				_, found, err := db.Find(misses[i*16:(i+1)*16], buf)
				if err != nil {
					return err
				}
				if found {
					return fmt.Errorf("unexpected hit at %d", i)
				}
			}
		}
		return nil
	})
	var deleted []bool
	if *flagResourceCRUD {
		deleted = make([]bool, n)
	}
	scanValues := func(expected int) error {
		var want uint64
		for i := 0; i < n; i++ {
			if !deleted[i] {
				want += uint64(vals[i*vs]) + uint64(vals[(i+1)*vs-1])
			}
		}
		for pass := 0; pass < *flagResourceScans; pass++ {
			seen := 0
			var sum uint64
			var bad error
			err := scan(func(k, v []byte) bool {
				if len(k) != 16 || len(v) != vs {
					bad = fmt.Errorf("bad scan record key=%d value=%d", len(k), len(v))
					return false
				}
				seen++
				sum += uint64(v[0]) + uint64(v[len(v)-1])
				return true
			})
			if err != nil {
				return err
			}
			if bad != nil {
				return bad
			}
			if seen != expected || sum != want {
				return fmt.Errorf("scan mismatch: rows=%d/%d checksum=%d/%d", seen, expected, sum, want)
			}
		}
		return nil
	}
	if *flagResourceCRUD {
		record("scan-values", n*(*flagResourceScans), func() error { return scanValues(n) })
	} else {
		record("scan", n, func() error {
			seen, err := db.Iterate()
			if err != nil {
				return err
			}
			if seen != n {
				return fmt.Errorf("scan returned %d of %d", seen, n)
			}
			return nil
		})
	}

	if !*flagNoPar {
		par := *flagPar
		readers := make([]reader, par)
		// Include connection creation in parallel CPU/wall cost; capture RSS
		// before closing them, including SQLite's per-connection page caches.
		record(fmt.Sprintf("find-hit-par%d", par), n*(*flagResourceReads), func() error {
			for g := range readers {
				r, err := db.NewReader()
				if err != nil {
					return err
				}
				readers[g] = r
			}
			var wg sync.WaitGroup
			errs := make([]error, par)
			for g, rd := range readers {
				wg.Add(1)
				go func(g int, rd reader) {
					defer wg.Done()
					var b []byte
					for pass := 0; pass < *flagResourceReads; pass++ {
						for j := g; j < n; j += par {
							b, errs[g] = check(rd, order[j], b)
							if errs[g] != nil {
								return
							}
						}
					}
				}(g, rd)
			}
			wg.Wait()
			for _, err := range errs {
				if err != nil {
					return err
				}
			}
			return nil
		})
		record("readers-close", par, func() error {
			for _, r := range readers {
				if err := r.Close(); err != nil {
					return err
				}
			}
			return nil
		})
	}
	if *flagResourceCRUD {
		changed := max(n/10, 1)
		for _, i := range order[:changed] {
			vals[(i+1)*vs-1] ^= 0xff
		}
		record("update", changed, func() error {
			for _, i := range order[:changed] {
				if err := db.Upsert(keys[i*16:(i+1)*16], vals[i*vs:(i+1)*vs]); err != nil {
					return err
				}
			}
			return nil
		})
		record("settle-update", n, db.Settle)
		record("verify-update", changed, func() error {
			for _, i := range order[:changed] {
				buf, err = check(db, i, buf)
				if err != nil {
					return err
				}
			}
			return nil
		})
		record("mixed-80read-20update", n, func() error {
			for j, i := range order {
				if j%10 < 8 {
					buf, err = check(db, i, buf)
					if err != nil {
						return err
					}
				} else {
					vals[(i+1)*vs-1] ^= 0xff
					if err := db.Upsert(keys[i*16:(i+1)*16], vals[i*vs:(i+1)*vs]); err != nil {
						return err
					}
				}
			}
			return nil
		})
		record("settle-mixed", n, db.Settle)
		record("delete", changed, func() error {
			for _, i := range order[:changed] {
				if err := remove(keys[i*16 : (i+1)*16]); err != nil {
					return err
				}
				deleted[i] = true
			}
			return nil
		})
		record("settle-delete", n, db.Settle)
		record("verify-delete", changed, func() error {
			for _, i := range order[:changed] {
				_, found, err := db.Find(keys[i*16:(i+1)*16], buf)
				if err != nil {
					return err
				}
				if found {
					return fmt.Errorf("deleted row still present: %d", i)
				}
			}
			return nil
		})
		record("scan-after-delete", (n-changed)*(*flagResourceScans), func() error { return scanValues(n - changed) })
	}

	record("close", 1, db.Close)
	runtime.KeepAlive(keys)
	runtime.KeepAlive(vals)
	runtime.KeepAlive(order)
	runtime.KeepAlive(misses)
	footprint, peakFootprint := resourceFootprint()
	output := map[string]any{
		"engine": name, "workload": workload, "n": n, "key_bytes": 16, "value_bytes": vs,
		"resource_crud": *flagResourceCRUD, "read_passes": *flagResourceReads, "scan_passes": *flagResourceScans,
		"readers": *flagPar, "gomaxprocs": runtime.GOMAXPROCS(0), "go_version": runtime.Version(),
		"cache_mb": *flagCache, "ours_cache_mb": *flagOursMB,
		"baseline_rss_bytes": baseline, "fixture_rss_bytes": fixtureRSS,
		"baseline_memory_footprint_bytes": baselineFootprint, "fixture_memory_footprint_bytes": fixtureFootprint,
		"memory_footprint_bytes": footprint, "process_peak_memory_footprint_bytes": peakFootprint,
		"fixture_payload_bytes": n * (16 + vs + 8 + 16),
		"phases":                phases, "disk_bytes": dirSize(edir), "process_peak_rss_bytes": resourcePeak(resourceUsage()),
		"notes": "RSS/peak include fixtures, native allocations and resident mappings; macOS memory footprint additionally accounts for compressed memory, but differs in treatment of file-backed pages. Go allocation counters exclude C allocations and anonymous mapped storage (including AptevaDB page/WAL buffers). Peaks are cumulative. Async/non-fsync writes. Parallel read includes reader setup and newly opened SQLite connection caches; its cache setting is per connection. Settle is explicit engine maintenance. CRUD scans consume full values; SQLite copies columns into Go buffers, AptevaDB/Pebble expose borrowed callbacks. Read phases repeat the same shuffled order. Update changes 10% of values, mixed is 80% point reads/20% updates, delete removes the updated 10%. Checks validate hit values, deletion, scan row counts and first/last-byte sums.",
	}
	if err := json.NewEncoder(os.Stdout).Encode(output); err != nil {
		panic(err)
	}
	if err := os.RemoveAll(filepath.Clean(edir)); err != nil {
		panic(err)
	}
}
